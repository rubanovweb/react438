import React from "react";
import "../css/Contacts.css";

function Contacts() {
  return (
    <section className="Contacts" id="contacts">
      <div className="container">
        <div className="row">
          <h2 className="col-12 section-title">Контакты</h2>
        </div>
      </div>
    </section>
  );
}

export default Contacts;
