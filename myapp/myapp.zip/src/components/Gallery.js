import React from "react";
import "../css/Gallery.css";

function Gallery() {
  return (
    <section className="Gallery" id="gallery">
      <div className="container">
        <div className="row">
          <h2 className="col-12 section-title">Фото</h2>
        </div>
      </div>
    </section>
  );
}

export default Gallery;
