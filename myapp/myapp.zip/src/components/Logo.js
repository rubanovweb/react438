import React from "react";

function Logo() {
  return (
    <a href="/">
      <img className="Logo" src="/img/logo.svg" alt="Логотип" />
    </a>
  );
}

export default Logo;
