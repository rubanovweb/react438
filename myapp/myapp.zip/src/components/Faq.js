import React from "react";
import "../css/Faq.css";

function Blog() {
  return (
    <section className="Faq" id="faq">
      <div className="container">
        <div className="row">
          <h2 className="col-12 section-title">FAQ</h2>
        </div>
      </div>
    </section>
  );
}

export default Blog;
