import React from "react";

function ArrowTop() {
  return <button className="ArrowTop animate__animated hidden"></button>;
}

export default ArrowTop;
